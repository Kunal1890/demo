package com.client;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Employee;
import com.sf.FactoryProvider;

public class Client {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session=FactoryProvider.getSession();
		
		Transaction transaction = session.beginTransaction();
		Employee employee = new Employee(105,"Adarsh","BLR");
		session.save(employee);
		transaction.commit();
		System.out.println("New Employee Added...!");

	}

}
