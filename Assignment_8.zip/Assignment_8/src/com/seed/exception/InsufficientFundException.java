package com.seed.exception;

public class InsufficientFundException {

}
