package com.seed.general;

public class SeedBank {

}
