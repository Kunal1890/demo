package com.seed.login;

public class Login {

}
