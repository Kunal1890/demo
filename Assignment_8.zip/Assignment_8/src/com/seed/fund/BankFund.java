package com.seed.fund;
import com.seed.exception.InsufficientFundException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


import com.seed.exception.InsufficientFundException;

public class BankFund {
	private double fund;

	public BankFund(double fund) {
		this.fund = fund;
	}

	public int checkFund(double amount) throws InsufficientFundException{
	 if(fund<amount){
	
	throw new InsufficientFundException("Insufficient "
	+"fund");
	 
	
	}return 0;
	 }
	public double debitFund(double amount){
		fund-=amount;

		 return fund;
		}

	}

